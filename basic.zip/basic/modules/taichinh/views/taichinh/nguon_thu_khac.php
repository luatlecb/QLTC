<?php
use kartik\form\ActiveForm;
use yii\helpers\Html;
$this->title='Quản lý thu nhập';
?>
<div class="container" style="background: #d0e6fd;">
    <div id="nguon_thu_co_dinh_form" style="max-width: 500px;margin: auto;">

    </div>
</div>
