<?php
use kartik\form\ActiveForm;
use yii\helpers\Html;
$this->title='Quản lý thu nhập';
?>
<div class="container" style="background: #d0e6fd;">
    <div id="nguon_thu_co_dinh_form" style="max-width: 500px;margin: auto;">
        <h1><?= Html::encode($this->title) ?></h1>
        <?php $form = ActiveForm::begin(); ?>
        <?= $form->field($model,'nguon_thu',['addon'=>['append'=>['content'=>'VND']]])->textInput(['maxlength' => true,'pattern'=>'[0-9]*','title'=>'Phải là số lớn hơn 0 !','oninvalid'=>'this.setCustomValidity("Phải là số lớn hơn 0")','oninput'=>'this.setCustomValidity(\'\')'])?>
        <div class="form-group">
            <button class="btn btn-success" >Lưu</button>
        </div>
        <?php $form=ActiveForm::end();?>
    </div>
</div>