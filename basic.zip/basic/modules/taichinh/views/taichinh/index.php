
<?php
echo '<pre>';
print_r($model);