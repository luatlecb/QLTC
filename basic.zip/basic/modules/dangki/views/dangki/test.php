<?php
print_r($_SESSION['user']);