<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\modules\dangki\models\Users */

$this->title = "Đăng kí";
$this->params['breadcrumbs'][] = ['label' => 'Users', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="container" style="background: #d0e6fd;">
    <div class="users-create" style="max-width: 500px;margin: auto;">
        <h1><?= Html::encode($this->title) ?></h1>
        <div class="users-form">
            <?php $form = ActiveForm::begin(); ?>

            <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>

            <?= $form->field($model, 'gender')->dropDownList(['nam'=>'Nam','nu'=>'Nữ'],['prompt'=>'Chọn giới tính']) ?>

            <?= $form->field($model, 'birthday')->textInput(['maxlength' => true]) ?>

            <?= $form->field($model, 'address')->textInput(['maxlength' => true]) ?>

            <?= $form->field($model, 'email')->textInput(['maxlength' => true]) ?>

            <?= $form->field($model, 'phone')->textInput(['maxlength' => true]) ?>

            <?= $form->field($model, 'username')->textInput(['maxlength' => true]) ?>

            <?= $form->field($model, 'password')->passwordInput(['maxlength' => true]) ?>

            <?/*= $form->field($model, 're-password')->passwordInput(['maxlength' => true]) */?>

            <div class="form-group">
                <?= Html::submitButton('Đăng kí', ['class' =>'btn btn-success']) ?>
            </div>

            <?php ActiveForm::end(); ?>
        </div>

    </div>
</div>